import { useState, useRef, useEffect, useCallback } from "react";

const SYSTEM_PROMPT = `Eres un asistente especializado en documentación de operaciones empresariales. Tu función es:

1. INDEXAR Y RECORDAR toda la información que el usuario te proporcione sobre operaciones, procesos, procedimientos, incidentes, etc.
2. RESPONDER preguntas sobre la documentación usando SOLO la información que se te ha proporcionado en esta sesión.
3. ESTRUCTURAR la información de manera clara y organizada.
4. IDENTIFICAR patrones, problemas recurrentes y sugerir mejoras basadas en los documentos.

Cuando el usuario agregue documentación, confirma qué información has indexado.
Cuando el usuario haga una pregunta, responde basándote exclusivamente en los documentos proporcionados y cita de qué documento proviene la información.
Si la información no está en los documentos, indícalo claramente.

Responde siempre en español de manera profesional y concisa.`;

const API_URL = "https://api.anthropic.com/v1/messages";

// Simple vector store in memory
let documentStore = [];

async function callClaude(messages, signal) {
  const res = await fetch(API_URL, {
    method: "POST",
    signal,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: SYSTEM_PROMPT,
      messages,
    }),
  });
  if (!res.ok) throw new Error(`API error: ${res.status}`);
  const data = await res.json();
  return data.content.map((b) => b.text || "").join("");
}

function buildContextMessage(docs) {
  if (docs.length === 0) return "";
  const context = docs
    .map((d, i) => `[DOC-${i + 1}] "${d.title}"\n${d.content}`)
    .join("\n\n---\n\n");
  return `BASE DE CONOCIMIENTO ACTUAL (${docs.length} documento${docs.length !== 1 ? "s" : ""}):\n\n${context}\n\n---\nFin de documentos indexados.`;
}

const Tag = ({ color, children }) => {
  const colors = {
    blue: "bg-sky-900/40 text-sky-300 border-sky-700/50",
    green: "bg-emerald-900/40 text-emerald-300 border-emerald-700/50",
    amber: "bg-amber-900/40 text-amber-300 border-amber-700/50",
    red: "bg-red-900/40 text-red-300 border-red-700/50",
    purple: "bg-violet-900/40 text-violet-300 border-violet-700/50",
  };
  return (
    <span className={`text-xs px-2 py-0.5 rounded border font-mono ${colors[color] || colors.blue}`}>
      {children}
    </span>
  );
};

const DocCard = ({ doc, index, onRemove }) => (
  <div className="group relative bg-zinc-900 border border-zinc-700/60 rounded-lg p-3 hover:border-zinc-500/60 transition-all duration-200">
    <div className="flex items-start justify-between gap-2">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <Tag color="blue">DOC-{index + 1}</Tag>
          <span className="text-zinc-200 text-sm font-medium truncate">{doc.title}</span>
        </div>
        <p className="text-zinc-500 text-xs line-clamp-2 leading-relaxed">{doc.content}</p>
        <div className="mt-1.5 flex items-center gap-2">
          <Tag color="green">{doc.content.split(" ").length} palabras</Tag>
          <span className="text-zinc-600 text-xs">{new Date(doc.timestamp).toLocaleTimeString("es", { hour: "2-digit", minute: "2-digit" })}</span>
        </div>
      </div>
      <button
        onClick={() => onRemove(index)}
        className="opacity-0 group-hover:opacity-100 text-zinc-600 hover:text-red-400 transition-all duration-150 text-lg leading-none mt-0.5 flex-shrink-0"
        title="Eliminar documento"
      >
        ×
      </button>
    </div>
  </div>
);

const Message = ({ msg }) => {
  const isUser = msg.role === "user";
  return (
    <div className={`flex gap-3 ${isUser ? "flex-row-reverse" : ""}`}>
      <div
        className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5 ${
          isUser ? "bg-sky-600 text-white" : "bg-violet-600 text-white"
        }`}
      >
        {isUser ? "U" : "AI"}
      </div>
      <div
        className={`max-w-[80%] rounded-xl px-4 py-2.5 text-sm leading-relaxed ${
          isUser
            ? "bg-sky-900/50 text-sky-100 border border-sky-700/40"
            : "bg-zinc-800 text-zinc-200 border border-zinc-700/40"
        }`}
        style={{ whiteSpace: "pre-wrap" }}
      >
        {msg.content}
      </div>
    </div>
  );
};

export default function RAGApp() {
  const [docs, setDocs] = useState([]);
  const [chatHistory, setChatHistory] = useState([]);
  const [query, setQuery] = useState("");
  const [docTitle, setDocTitle] = useState("");
  const [docContent, setDocContent] = useState("");
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("chat");
  const [statusMsg, setStatusMsg] = useState("");
  const chatEndRef = useRef(null);
  const abortRef = useRef(null);

  useEffect(() => {
    documentStore = docs;
  }, [docs]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatHistory, loading]);

  const addDoc = useCallback(async () => {
    if (!docTitle.trim() || !docContent.trim()) return;
    const newDoc = { title: docTitle.trim(), content: docContent.trim(), timestamp: Date.now() };
    const newDocs = [...docs, newDoc];
    setDocs(newDocs);
    documentStore = newDocs;

    setStatusMsg("Indexando documento...");
    setLoading(true);

    const contextMsg = buildContextMessage(newDocs);
    const messages = [
      ...(chatHistory.length > 0 ? chatHistory : []),
      {
        role: "user",
        content: `${contextMsg}\n\nAcabo de agregar un nuevo documento: "${newDoc.title}". Confirma brevemente que lo has indexado y menciona los temas clave que cubre.`,
      },
    ];

    try {
      const reply = await callClaude(messages);
      const newHistory = [
        ...chatHistory,
        { role: "user", content: `📄 Documento agregado: "${newDoc.title}"` },
        { role: "assistant", content: reply },
      ];
      setChatHistory(newHistory);
      setDocTitle("");
      setDocContent("");
      setActiveTab("chat");
      setStatusMsg("");
    } catch (e) {
      setStatusMsg("Error al indexar. Intenta de nuevo.");
    } finally {
      setLoading(false);
    }
  }, [docs, docTitle, docContent, chatHistory]);

  const sendQuery = useCallback(async () => {
    if (!query.trim() || loading) return;
    const user